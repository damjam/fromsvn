package com.flink.mail.cmp;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Flags.Flag;

import com.flink.mail.MailException;
import com.flink.mail.info.AbstractBaseMailInfo;
import com.flink.mail.info.CompositMailInfo;
import com.flink.mail.info.SimpleHtmlMailInfo;
import com.flink.mail.info.SimpleTextMailInfo;

/**
 *  �ʼ��齨��
 * @author ly
 * @date   2011-02-22
 */
public class FlinkMailComponent extends AbstractBaseFlinkMailComponent{
	
	public void sendHtmlMail(SimpleHtmlMailInfo simpleHtmlMailInfo)
			throws MailException {
		super.getHelper().sendSimpleHtmlMailInfo(simpleHtmlMailInfo);
	}

	public void sendTextMail(SimpleTextMailInfo simpleTextMailInfo)
			throws MailException {
		super.getHelper().sendSimpleTextMailInfo(simpleTextMailInfo);
	}

	public void sendCompositMail(CompositMailInfo compositMailInfo)
			throws MailException {
		super.getHelper().sendCompositMailInfo(compositMailInfo);
		
	}

	public Message[] getAllMailMsg(Folder folder) throws MailException {
		
		return super.getHelper().getAllMsg(folder);
	}

	public AbstractBaseMailInfo getMailMsgInfo(Message msg)
			throws MailException {
		 
		return super.getHelper().getMsgInfo(msg);
	}

	public void setMailMsgFlag(Message msg, Flag flag) throws MailException {
		 super.getHelper().setFlag(msg, flag);
	}


}
