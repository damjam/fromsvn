package com.flink.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

/**
 * ��½��֤��
 * @author ly
 * @date  2011-02-22 
 */
public class MailAuthenticator extends Authenticator {

	private String userName;
	
	private String password;
	
	/**
	 * ��ȡ�û���
	 * @return
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * �����û���
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}


	/**
	 * ��ȡ����
	 * @return
	 */
	public String getPassword() {
		return password;
	}


	/**
	 * ��������
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}



	protected PasswordAuthentication getPasswordAuthentication() {
		
		return new PasswordAuthentication(this.getUserName(),this.getPassword());
	}

	
}
