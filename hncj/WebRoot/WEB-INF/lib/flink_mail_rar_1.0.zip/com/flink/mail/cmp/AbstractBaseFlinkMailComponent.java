package com.flink.mail.cmp;

import com.flink.mail.MailHelper;

/**
 * �ʼ��齨��
 * @author ly
 * @date   2011-02-22
 */
public abstract class AbstractBaseFlinkMailComponent implements IBaseFlinkMailComponent{

	private MailHelper helper;
	
	public void setHelper(MailHelper helper) {
		this.helper = helper;
	}

	public MailHelper getHelper() {
		return helper;
	}

	
}
