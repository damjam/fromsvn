package com.flink.mail;

/**
 *  �ʼ�����
 * @author ly
 * @date  2011-02-22 
 */
public class MailConstant {

	/**
	 * smtp Э��
	 */
	public static final String PROTOCOL_SMTP="smtp";
	
	/**
	 * pop3 Э��
	 */
	public static final String PROTOCOL_POP3="pop3";
	
	/**
	 * inbox �ļ���
	 */
	public static final String FOLDER_INPUT="inbox";
	
	/**
	 * ����
	 */
	public static final String CHARSET_GBK="gbk";
	
	
}
