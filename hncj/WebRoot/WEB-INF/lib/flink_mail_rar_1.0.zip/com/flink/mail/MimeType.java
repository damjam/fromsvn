package com.flink.mail;

/**
 *  邮件发送内容类型
 * @author ly
 * @date  2011-02-21 
 */
public class MimeType {
	
	/**
	 * 文本格式
	 */
	public static final String TEXT="text/plain";
	
	/**
	 * html格式
	 */
	public static final String HTML="text/html";
	
	/**
	 * 邮件解析
	 */
	public static final String MULTIPART="multipart/*";
	
	
}
