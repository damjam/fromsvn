package com.flink.mail.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.mail.Message;
import javax.mail.Store;

import com.flink.mail.MailConfig;
import com.flink.mail.MailConstant;
import com.flink.mail.MailException;
import com.flink.mail.MailHelper;
import com.flink.mail.cmp.FlinkMailComponent;
import com.flink.mail.cmp.IBaseFlinkMailComponent;
import com.flink.mail.info.AbstractBaseMailInfo;
import com.flink.mail.info.CompositMailInfo;
import com.flink.mail.info.SimpleHtmlMailInfo;
import com.flink.mail.info.SimpleTextMailInfo;
import com.sun.mail.pop3.POP3Folder;

public class TestFlinkMailComponent {

	/**
	 * ��ȡ��������
	 * @return
	 */
	public MailConfig getSendMailConfig(){
		MailConfig mailConfig=new MailConfig();
		mailConfig.setSendhost("smtp.163.com");
		mailConfig.setSendUserName("haohuakaizaiweilai");
		mailConfig.setSendPassword("287760563");
		mailConfig.setSendPort("25");
		
		return mailConfig;
	}
	
	/**
	 * ��ȡ��������
	 * @return
	 */
	public MailConfig getReceiveMailConfig(){
		
		MailConfig mailConfig=new MailConfig();
		mailConfig.setReceiveHost("pop3.163.com");
		mailConfig.setReceiveUserName("kaizaiweilai");
		mailConfig.setReceivePassword("287760563");
		mailConfig.setReceivePort("110");
		
		return mailConfig;
	}
	
	/**
	 * �����ı��ʼ�
	 * @throws MailException
	 */
	public void testSimpleTextMail() throws MailException{
		
		SimpleTextMailInfo info=new SimpleTextMailInfo();
		info.setFrom(new String[]{"haohuakaizaiweilai@163.com"});
		info.setSubject("userInfo");
		info.setTo(new String[]{"kaizaiweilai@163.com"});
		info.setTextContent("hello world #################");
		info.setEncoding(MailConstant.CHARSET_GBK);
		
		IBaseFlinkMailComponent baseFlinkMailComponent=new FlinkMailComponent();
		MailHelper helper=new MailHelper();
		helper.setMailConfig(this.getSendMailConfig());
		
		baseFlinkMailComponent.setHelper(helper);
		baseFlinkMailComponent.sendTextMail(info);
		 
	}
	
	/**
	 * ����html�ʼ�
	 * @throws MailException
	 */
	public void testSimpleHtmlMail() throws MailException{
		
		SimpleHtmlMailInfo info=new SimpleHtmlMailInfo();
		info.setFrom(new String[]{"haohuakaizaiweilai@163.com"});
		info.setSubject("你好");
		info.setTo(new String[]{"kaizaiweilai@163.com"});
		
		StringBuffer sb=new StringBuffer();
		sb.append("<html>");
			sb.append("<head>你好</head>");
			sb.append("<body><h1>hello world</h1></body>");
		sb.append("</html>");
		info.setHtmlContent(sb.toString());
		info.setEncoding(MailConstant.CHARSET_GBK);
		
		IBaseFlinkMailComponent baseFlinkMailComponent=new FlinkMailComponent();
		MailHelper helper=new MailHelper();
		helper.setMailConfig(this.getSendMailConfig());
		
		baseFlinkMailComponent.setHelper(helper);
		baseFlinkMailComponent.sendHtmlMail(info);
		 
	}
	
	/**
	 * ���Ը����ʼ�
	 * @throws MailException
	 */
	public void testCompositMail() throws MailException{
		
		CompositMailInfo info=new CompositMailInfo();
		info.setFrom(new String[]{"haohuakaizaiweilai@163.com"});
		info.setSubject("userInfo");
		info.setTo(new String[]{"kaizaiweilai@163.com"});
		info.setTextContent("hello world #################");
		info.setEncoding(MailConstant.CHARSET_GBK);
		info.setFile(new File[]{new File("你好.txt")});
		
		IBaseFlinkMailComponent baseFlinkMailComponent=new FlinkMailComponent();
		MailHelper helper=new MailHelper();
		helper.setMailConfig(this.getSendMailConfig());
		
		baseFlinkMailComponent.setHelper(helper);
		baseFlinkMailComponent.sendCompositMail(info);
		 
		try{
			//FileOutputStream fos=new FileOutputStream("aa.txt");
			//fos.write(new String("12345678").getBytes());
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	/**
	 * ���Խ����ʼ�
	 * @throws MailException
	 */
	public void testReceiveMail() throws MailException{
		
		Store store =null;
		POP3Folder folder =null;
		try{
			IBaseFlinkMailComponent baseFlinkMailComponent=new FlinkMailComponent();
			MailHelper helper=new MailHelper();
			helper.setMailConfig(this.getReceiveMailConfig());
			baseFlinkMailComponent.setHelper(helper);
			
			store = helper.getReceiveSession().getStore(MailConstant.PROTOCOL_POP3);
			store.connect("pop3.163.com","kaizaiweilai","287760563");
			 
		   folder=(POP3Folder)store.getFolder("inbox");
			
		   Message[] msg = baseFlinkMailComponent.getAllMailMsg(folder);
	       for(int i=0;i<msg.length;i++){
	    	   System.out.println("#################/////"+folder.getUID(msg[i]));
	    	    AbstractBaseMailInfo info = baseFlinkMailComponent.getMailMsgInfo(msg[i]);
				if(info instanceof SimpleTextMailInfo){
					System.out.println("SimpleTextMailInfo....................");
					SimpleTextMailInfo simpleTextMailInfo=(SimpleTextMailInfo)info;
					System.out.println("SimpleTextMailInfo: "+simpleTextMailInfo.getTextContent());
				}
				
				if(info instanceof SimpleHtmlMailInfo){
					System.out.println("SimpleHtmlMailInfo....................");
					SimpleHtmlMailInfo simpleHtmlMailInfo=(SimpleHtmlMailInfo)info;
					System.out.println("SimpleHtmlMailInfo: "+simpleHtmlMailInfo.getHtmlContent());
				}
				
				if(info instanceof CompositMailInfo){
					System.out.println("CompositMailInfo....................");
					CompositMailInfo compositMailInfo=(CompositMailInfo)info;
					System.out.println("compositMailInfo: "+compositMailInfo.getTextContent());
					
					//文件
					InputStream[] inputStreams = compositMailInfo.getInputStreams();
					for(int j=0;j<inputStreams.length;j++){
						BufferedReader bis=new BufferedReader(new InputStreamReader(inputStreams[j]));
						System.out.println(bis.readLine());
					}
				}
	       }
			folder.close(true);
			store.close();
			
		}catch (Exception e) {
			throw new MailException(e.getMessage());
		}finally{
			try{
				if(null!=folder && folder.isOpen()){
					folder.close(true);
				}
				if(null!=store && store.isConnected()){
					store.close();
				}
			}catch (Exception e) {
				throw new MailException(e.getMessage());
			}
		}
	}
	
	
	public static void main(String[] args) {
		try{
		 	TestFlinkMailComponent testFlinkMailComponent=new TestFlinkMailComponent();
			 //testFlinkMailComponent.testSimpleTextMail();
			
			//testFlinkMailComponent.testSimpleHtmlMail(); 
		 	//testFlinkMailComponent.testCompositMail();
		 	
		 	testFlinkMailComponent.testReceiveMail();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
