package com.flink.mail;

/**
 * �ʼ��쳣��
 * @author ly
 * @date   2011-02-21
 */
public class MailException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Ĭ�Ϲ���
	 * @param msg
	 */
	public MailException(String msg){
		super(msg);
	}

}
