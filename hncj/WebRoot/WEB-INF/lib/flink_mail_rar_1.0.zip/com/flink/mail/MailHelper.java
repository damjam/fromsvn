package com.flink.mail;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.FetchProfile;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Flags.Flag;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

import com.flink.mail.info.AbstractBaseMailInfo;
import com.flink.mail.info.CompositMailInfo;
import com.flink.mail.info.SimpleHtmlMailInfo;
import com.flink.mail.info.SimpleTextMailInfo;

/**
 *  邮件辅助类
 * @author ly
 * @date  2011-02-21 
 */
public class MailHelper {

	/**
	 * 邮件基本信息配置类
	 */
	private MailConfig mailConfig;
	
	private final String host="mail.smtp.host";
	private final String auth="mail.smtp.auth";
	private final String port="mail.smtp.port";
	private final String top="mail.pop3.disabletop";
	
	/**
	 * 默认构造
	 */
	public MailHelper(){
		
	}
	
	/**
	 * 默认构造
	 */
	public MailHelper(MailConfig mailConfig){
		
	}
	
	/**
	 * 获取邮件配置信息
	 * @return
	 */
	public MailConfig getMailConfig() {
		return mailConfig;
	}

	/**
	 * 设置邮件配置信息
	 * @param mailConfig
	 */
	public void setMailConfig(MailConfig mailConfig) {
		this.mailConfig = mailConfig;
	}
	
	/**
	 * 获取发送属性对象
	 * @param config
	 * @return
	 */
	private Properties getSendProps(MailConfig mailConfig) throws MailException{
		
		Properties properties=new Properties();
		
		properties.put(this.host, mailConfig.getSendhost());
		properties.put(this.port, mailConfig.getSendPort());
		properties.put(this.auth, "true");
		
		return properties;
	}
	
	/**
	 * 获取接收属性对象
	 * @param config
	 * @return
	 */
	private Properties getReceiveProps(MailConfig mailConfig) throws MailException{
		
		Properties properties=new Properties();
		
		properties.put(this.host, mailConfig.getReceiveHost());
		properties.put(this.port, mailConfig.getReceivePort());
		properties.put(this.auth, "true");
		properties.put(this.top, "true");
		
		return properties;
	}
	
	/**
	 * 获取发送发送认证对象
	 * @param protocol
	 * @return
	 */
    public Authenticator getSendAuthenticator()throws MailException{
    	
    	MailConfig mailConfig=this.getMailConfig();
    	if(null==mailConfig){
    		throw new MailException("邮件发送服务器配置对象为空!");
    	}
    	
    	//是否为发送配置有效
    	mailConfig.isValidSendConfig();
    	
    	MailAuthenticator mailAuthenticator=new MailAuthenticator();
    	mailAuthenticator.setUserName(this.getMailConfig().getSendUserName());
    	mailAuthenticator.setPassword(this.getMailConfig().getSendPassword());
    	 
		return mailAuthenticator;
		 
    }
    
    /**
	 * 获取接收认证对象
	 * @param protocol
	 * @return
	 */
    public Authenticator getReceiveAuthenticator()throws MailException{
    	
    	MailConfig mailConfig=this.getMailConfig();
    	if(null==mailConfig){
    		throw new MailException("邮件接收服务器配置对象为空!");
    	}
    	
    	//是否为发送配置有效
    	mailConfig.isValidReceiveConfig();
    	
    	MailAuthenticator mailAuthenticator=new MailAuthenticator();
    	mailAuthenticator.setUserName(this.getMailConfig().getReceiveUserName());
    	mailAuthenticator.setPassword(this.getMailConfig().getReceivePassword());
    	 
		return mailAuthenticator;
		 
    }
	
	/**
	 * 获取发送transPort对象
	 * @param protocol
	 * @return
	 */
    public Session getSendSession()throws MailException{
    	
    	MailConfig mailConfig=this.getMailConfig();
    	if(null==mailConfig){
    		throw new MailException("邮件发送服务器配置对象为空!");
    	}
    	
    	//是否为发送配置有效
    	mailConfig.isValidSendConfig();
    	
    	Session  session=Session.getDefaultInstance(this.getSendProps(this.getMailConfig()),this.getSendAuthenticator());
    	 
		return session;
		 
    }
    
    /**
	 * 获取发送transPort对象
	 * @param protocol
	 * @return
	 */
    public Session getReceiveSession()throws MailException{
    	
    	MailConfig mailConfig=this.getMailConfig();
    	if(null==mailConfig){
    		throw new MailException("邮件发送服务器配置对象为空!");
    	}
    	
    	//是否为发送配置有效
    	mailConfig.isValidReceiveConfig();
    	
    	Session  session=Session.getDefaultInstance(this.getReceiveProps(this.getMailConfig()),this.getReceiveAuthenticator());
    	 
		return session;
		 
    }
	
	 /**
	  * 发送简单的文本邮件信息
	  * @param simpleTextMailInfo
	  * @throws MailException
	  */
    public void sendSimpleTextMailInfo(SimpleTextMailInfo simpleTextMailInfo) throws MailException {
    	
    	try {
    		 			
			Message message=this.getMailInfo(simpleTextMailInfo);
			Transport.send(message);
		} catch (Exception e) {
			throw new MailException(e.getMessage());
		}
    }

    /**
	  * 发送简单的文本邮件信息
	  * @param simpleTextMailInfo
	  * @throws MailException
	  */
   public void sendSimpleHtmlMailInfo(SimpleHtmlMailInfo simpleHtmlMailInfo) throws MailException {
   	
	   try {
			Message message=this.getMailInfo(simpleHtmlMailInfo);
			Transport.send(message);
	   } catch (Exception e) {
			throw new MailException(e.getMessage());
	   }
   }
   
     /**
	  * 发送带附件的邮件信息
	  * @param simpleTextMailInfo
	  * @throws MailException
	  */
	 public void sendCompositMailInfo(CompositMailInfo compositeMailInfo) throws MailException {
	 	
	 	try {
				Message message=this.getMailInfo(compositeMailInfo);
				Transport.send(message);
			} catch (Exception e) {
				throw new MailException(e.getMessage());
			}
	 }
	 
	 /**
	  * 获取指定文件夹的邮件信息
	  * @param folder
	  * @return
	  * @throws MailException
	  */
	 public Message[] getAllMsg(Folder folder) throws MailException{
		 try{
			 folder.open(Folder.READ_WRITE);
				
		     FetchProfile profile = new FetchProfile(); 
	         profile.add(FetchProfile.Item.ENVELOPE); 
	         Message messages[] = folder.getMessages(); 
	         folder.fetch(messages, profile);
	         
	         return messages;
		 }catch (Exception e) {
			throw new MailException(e.getMessage());
		}
	 }
	 
	/**
	 * 接收邮件信息
	 * @param msgs 制定文件夹的邮件信息
	 * @param setFlag 在邮件访问的过程中设置的标志  null  不设置标志
	 * @param filterFlag 邮件访问的过程中过滤的标志 null 不过滤
	 * @return
	 * @throws MailException
	 */
	 public AbstractBaseMailInfo getMsgInfo(Message msg) throws MailException {
	 	
	 	try {
				//文本邮件
				if(msg.isMimeType(MimeType.TEXT)){
					SimpleTextMailInfo simpleTextMailInfo=this.getSimpleTextMailInfo(msg);
					return simpleTextMailInfo;
				}
				
				//html邮件
				if(msg.isMimeType(MimeType.HTML)){
					SimpleHtmlMailInfo simpleHtmlMailInfo = this.getSimpleHtmlMailInfo(msg);
					return simpleHtmlMailInfo;
				}
				
				//复合邮件
				if(msg.isMimeType(MimeType.MULTIPART)){
					CompositMailInfo compositMailInfo=this.getCompositMailInfo(msg);
					return compositMailInfo;
				}
	 	
				return null;
	 	} catch (Exception e) {
				throw new MailException(e.getMessage());
		}
	 }
	 
	 /**
	  * 设置邮件标志
	  * @param msg
	  * @param flag
	  */
	 public void setFlag(Message msg,Flag flag) throws MailException{
		 try{
			 if(!isSetFlag(msg, flag)){
				 msg.setFlag(flag,true);
			 }
		 }catch (Exception e) {
			throw new MailException(e.getMessage());
		}
	 }

	 /**
	  * 判断是否已经设置标志
	  * @param msg
	  * @param setFlag
	  * @return
	 * @throws MessagingException 
	  */
	  public boolean isSetFlag(Message msg, Flag setFlag) throws MailException {
		try{
			if(null==setFlag){
				return true;
			}
			
			Flag[] flags = msg.getFlags().getSystemFlags();
			 
			for (Flag itemFlag : flags) {
				if(itemFlag==setFlag){
					return true;
				}
			}
			
			return false;
		
		}catch (Exception e) {
			throw new MailException(e.getMessage());
		}
	}

	/**
	  * 判断当前邮件是否为制定的标志
	  * @param msg
	  * @param filterFlag  
	  * @return
	 * @throws MessagingException 
	  */
	 public boolean isFilterMsg(Message msg, Flag flag) throws MailException {
		
		 try{
			 //不过滤
			 if(null==flag){
				return false;
			 }
			 
			Flag[] flags = msg.getFlags().getSystemFlags();
			 
			for (Flag itemFlag : flags) {
				if(itemFlag==flag){
					return true;
				}
			}
			
			return false;
		 }catch (MessagingException e) {
			
			 throw new MailException(e.getMessage());
		}
	}

	/**
	  * 获取邮件信息对象
	  * @param msg
	  * @return
	  */
    public SimpleTextMailInfo getSimpleTextMailInfo(Message msg) throws MailException {
    	
    	SimpleTextMailInfo info=new SimpleTextMailInfo();
    	
    	try{
    		
	    	String []from=new String[msg.getFrom().length];
	    	for (int i=0;i<msg.getFrom().length;i++) {
				from[i]=msg.getFrom()[i].toString();
			}
	    	info.setFrom(from);
	    	
	    	String []to=new String[msg.getReplyTo().length];
	    	for (int i=0;i<msg.getReplyTo().length;i++) {
				to[i]=msg.getReplyTo()[i].toString();
			}
	    	info.setTo(to);
	    	
	    	if(null!=msg.getRecipients(RecipientType.CC) && msg.getRecipients(RecipientType.CC).length>0){
		    	String []copyTo=new String[msg.getReplyTo().length];
		    	for (int i=0;i< msg.getRecipients(RecipientType.CC).length;i++) {
		    		copyTo[i]= msg.getRecipients(RecipientType.CC)[i].toString();
				}
		    	
		    	info.setCopyTo(copyTo);
	    	}
	    	
	    	info.setSubject(msg.getSubject());
	    	info.setTextContent((String)msg.getContent());
			return info;
			
    	}catch (Exception e) {
			throw new MailException(e.getMessage());
		}
	}
    
    /**
	  * 获取邮件信息对象
	  * @param msg
	  * @return
	  */
   public SimpleHtmlMailInfo getSimpleHtmlMailInfo(Message msg) throws MailException {
   	
	    SimpleHtmlMailInfo info=new SimpleHtmlMailInfo();
	   	
	   	try{
	   		
	    	String []from=new String[msg.getFrom().length];
	    	for (int i=0;i<msg.getFrom().length;i++) {
				from[i]=msg.getFrom()[i].toString();
			}
	    	info.setFrom(from);
	    	
	    	String []to=new String[msg.getReplyTo().length];
	    	for (int i=0;i<msg.getReplyTo().length;i++) {
				to[i]=msg.getReplyTo()[i].toString();
			}
	    	info.setTo(to);
	    	
	    	if(null!=msg.getRecipients(RecipientType.CC) && msg.getRecipients(RecipientType.CC).length>0){
		    	String []copyTo=new String[msg.getReplyTo().length];
		    	for (int i=0;i< msg.getRecipients(RecipientType.CC).length;i++) {
		    		copyTo[i]= msg.getRecipients(RecipientType.CC)[i].toString();
				}
		    	
		    	info.setCopyTo(copyTo);
	    	}
	    	
	    	info.setSubject(msg.getSubject());
	    	info.setHtmlContent((String)msg.getContent());
			return info;
				
	   	}catch (Exception e) {
				throw new MailException(e.getMessage());
		}
	}
   
   /**
	  * 获取邮件信息对象
	  * @param msg
	  * @return
	  */
   public CompositMailInfo getCompositMailInfo(Message msg) throws MailException {
 	
	   CompositMailInfo info=new CompositMailInfo();
	   	
	   	try{
	   		
	    	String []from=new String[msg.getFrom().length];
	    	for (int i=0;i<msg.getFrom().length;i++) {
				from[i]=msg.getFrom()[i].toString();
			}
	    	info.setFrom(from);
	    	
	    	String []to=new String[msg.getReplyTo().length];
	    	for (int i=0;i<msg.getReplyTo().length;i++) {
				to[i]=msg.getReplyTo()[i].toString();
			}
	    	info.setTo(to);
	    	
	    	if(null!=msg.getRecipients(RecipientType.CC) && msg.getRecipients(RecipientType.CC).length>0){
		    	String []copyTo=new String[msg.getReplyTo().length];
		    	for (int i=0;i< msg.getRecipients(RecipientType.CC).length;i++) {
		    		copyTo[i]= msg.getRecipients(RecipientType.CC)[i].toString();
				}
		    	
		    	info.setCopyTo(copyTo);
	    	}
	    	
	    	info.setSubject(msg.getSubject());
	    	
	    	//附件解析
	    	Multipart part=(Multipart )msg.getContent();
	    	int count = part.getCount();
	    	String fileName=null;
	    	ArrayList<InputStream> list=new ArrayList<InputStream>();
	    	for(int i=0;i<count;i++){
	    		BodyPart bodyPart = part.getBodyPart(i);
	    		info.setTextContent((String)bodyPart.getContent());
	    		fileName=bodyPart.getFileName();
	    		if(null!=bodyPart.getFileName()){
	    			fileName = MimeUtility.decodeText(bodyPart.getFileName());
	    			info.setFileName(fileName);
	    			list.add(bodyPart.getInputStream());
	    		}
	    	}
	        
	    	InputStream []is=new InputStream[list.size()];
	        for (int i=0;i<is.length;i++) {
	        	is[i]=list.get(i);
			}
	        
	        info.setInputStreams(is);
			return info;
				
	   	}catch (Exception e) {
				throw new MailException(e.getMessage());
		}
	}

   
	/**
     * 初始化邮件信息
     * @param simpleTextMailInfo
     * @return
     * @throws MailException 
     */
	private Message getMailInfo(AbstractBaseMailInfo mailInfo) throws MailException {
		
		//检测邮件的合法性
		mailInfo.isValidMail();
		
		Message message=new MimeMessage(this.getSendSession());
		this.initMailInfo(message, mailInfo);
		
		try{
			//简单文本邮件
			if(mailInfo instanceof SimpleTextMailInfo){
				 message.setContent(((SimpleTextMailInfo) mailInfo).getTextContent(),
						 MimeType.TEXT+";charset="+mailInfo.getEncoding());
				 return message;
			}	
			
			//简单html邮件
			if(mailInfo instanceof SimpleHtmlMailInfo){
				 message.setContent(((SimpleHtmlMailInfo) mailInfo).getHtmlContent(),
						 MimeType.HTML+";charset="+mailInfo.getEncoding());
				 return message;
			}	
			
			//带附件的邮件
			if(mailInfo instanceof CompositMailInfo){
				 Multipart multipart=new MimeMultipart();
				 
				 CompositMailInfo compositeMailInfo=(CompositMailInfo)mailInfo;
				 MimeBodyPart bodyPart;
				 if(null!=compositeMailInfo.getTextContent() && !"".equals(compositeMailInfo.getTextContent())){
					 bodyPart=new MimeBodyPart();
					 bodyPart.setContent(compositeMailInfo.getTextContent(), MimeType.TEXT+";charset="+mailInfo.getEncoding());
					 multipart.addBodyPart(bodyPart);
				 }
				 
				 //附件处理
				 for(int i=0;i<compositeMailInfo.getFile().length;i++){
					 File file = compositeMailInfo.getFile()[i];
					 bodyPart=new MimeBodyPart();
					 bodyPart.setDataHandler(new DataHandler(new FileDataSource(file)));
					 bodyPart.setFileName(MimeUtility.encodeText(file.getName()));
					 multipart.addBodyPart(bodyPart);
				 }
				 
				 message.setContent(multipart);
				 return message;
			}	
			
		}catch (Exception e) {
			throw new MailException(e.getMessage());
		}
		
		return null;
	}
    
	//初始化邮件相关信息
	private void initMailInfo(Message message,AbstractBaseMailInfo mailInfo) throws MailException{
		 try{
			
			 Address[] from=new Address[mailInfo.getFrom().length];
			 for(int i=0;i<from.length;i++){
				 from[i]=new InternetAddress(mailInfo.getFrom()[i]);
			 }
			 
			 //设置发送者
			 message.addFrom(from);
			 
			 Address[] to=new Address[mailInfo.getTo().length];
			 for(int i=0;i<to.length;i++){
				 to[i]=new InternetAddress(mailInfo.getTo()[i]);
			 }
			 
			 //设置接收者
			 message.addRecipients(Message.RecipientType.TO, to);
			 
			 if(null!=mailInfo.getCopyTo() && mailInfo.getCopyTo().length>0){
				 Address[] copyTo=new Address[mailInfo.getCopyTo().length];
				 for(int i=0;i<copyTo.length;i++){
					 copyTo[i]=new InternetAddress(mailInfo.getCopyTo()[i]);
				 } 
				 
				 //设置抄送对象
				 message.addRecipients(Message.RecipientType.BCC, copyTo);
			 }
			 
			 //设置主题
			 message.setSubject(mailInfo.getSubject());
		 }catch (Exception e) {
			throw new MailException(e.getMessage());
		}
	}
	
}
