package com.flink.compress;

/**
 * ϵͳ����
 * @author ly
 * @date  2011-02-23 
 */
public class CompressConstant {
	
	/**
	 * windows ϵͳ
	 */
	public static final String WINDOWS="WINDOWS";
	
	/**
	 * linux ϵͳ
	 */
	public static final String LINUX="LINUX";
	
}
