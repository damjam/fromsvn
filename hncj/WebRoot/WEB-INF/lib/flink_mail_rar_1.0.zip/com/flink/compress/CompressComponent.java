package com.flink.compress;

import java.io.File;

public class CompressComponent {

	public static void main(String[] args) {
		File file=new File("c:\\userInfo.txt");
		System.out.println(file.getName());
		
	}
}
