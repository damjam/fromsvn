package com.flink.compress;

import java.io.File;

/**
 * ѹ��������
 * @author ly
 * @date  2011-02-23 
 */
public abstract class AbstractBaseFlinkCompressComponent implements IBaseFlinkCompressComponent {

	/**
	 * ��ȡϵͳƽ̨
	 * @return
	 */
	public String getSysPlatform(){
		if(File.separator.equals("//")){
			
			return CompressConstant.LINUX;
		}else{
			
			return CompressConstant.WINDOWS;
		}
	}
}
