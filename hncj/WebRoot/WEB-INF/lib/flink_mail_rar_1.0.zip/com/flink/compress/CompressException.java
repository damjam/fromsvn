package com.flink.compress;

/**
 * ѹ���쳣��
 * @author ly
 * @date  2011-02-23 
 */
public class CompressException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CompressException(String msg){
		super(msg);
	}
}
