package com.flink.compress.rar;


import com.flink.compress.AbstractBaseFlinkCompressComponent;
import com.flink.compress.CompressConstant;
import com.flink.compress.CompressException;

/**
 * RAR���
 * @author ly
 * @date  2011-02-23 
 */
public class FlinkRARCompressComponent extends AbstractBaseFlinkCompressComponent {

	public void compress(String srcFile, String desFile, String password,
			String rarExePath) throws CompressException {
		 
		if(CompressConstant.WINDOWS.equals(super.getSysPlatform())){
			if(null==rarExePath){
				throw  new CompressException("δָ��ѹ������װ·��");
			}
			WinRARCompressHelper.compress(srcFile, desFile, password, rarExePath);
		}else{
			LinuxRarCompressHelper.compress(srcFile, desFile, password);
		}
	}

	public void deCompress(String srcFile, String desPath, String password,
			String rarExePath) throws CompressException {
		if(CompressConstant.WINDOWS.equals(super.getSysPlatform())){
			if(null==rarExePath){
				throw  new CompressException("δָ��ѹ������װ��ַ");
			}
			WinRARCompressHelper.deCompress(srcFile, desPath, password, rarExePath);
		}else{
			if(CompressConstant.LINUX.equals(super.getSysPlatform())){
				LinuxRarCompressHelper.deCompress(srcFile, desPath, password);
			}
		}
		
	}

	  
}
