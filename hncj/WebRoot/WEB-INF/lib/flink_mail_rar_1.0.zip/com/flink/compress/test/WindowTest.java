package com.flink.compress.test;

import com.flink.compress.CompressException;
import com.flink.compress.IBaseFlinkCompressComponent;
import com.flink.compress.rar.FlinkRARCompressComponent;

/**
 * windows ����
 * @author ly
 * @date  2011-02-23 
 */
public class WindowTest {

	private String winRarExe="C:\\Program Files\\WinRAR\\WinRAR.exe";

	/**
	 * ѹ������
	 * @throws CompressException
	 */
	public void testWinRar() throws CompressException{
		String srcFile="D:\\rartest\\a.txt";
		String desFile="D:\\rartest\\a.rar";
		IBaseFlinkCompressComponent component=new FlinkRARCompressComponent();
		component.compress(srcFile, desFile, "1", winRarExe);
	}
	
	/**
	 * ��ѹ����
	 * @throws CompressException
	 */
	public void testWinUnrar() throws CompressException{
		String srcFile="D:\\rartest\\a.rar";
		String desPath="D:\\rartest\\";
		IBaseFlinkCompressComponent component=new FlinkRARCompressComponent();
		component.deCompress(srcFile, desPath, "1", winRarExe);
	}
	
	public static void main(String[] args) {
		try{
			WindowTest testCompress=new WindowTest();
			testCompress.testWinRar();
			
			//testCompress.testWinUnrar();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
