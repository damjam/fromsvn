package com.flink.compress.rar;

import com.flink.compress.CompressException;

/**
 * RARѹ�������� windows 
 * @author ly
 * @date  2011-02-23 
 */
public class WinRARCompressHelper {
	
	/**
	 * ѹ��
	 * @param srcFile Դ�ļ�
	 * @param desFile  ѹ�����ļ�
	 * @param password  ѹ�����룬 Ϊ�շ�����ѹ��
	 * @param rarExePath  ѹ������װ·��
	 * @throws CompressException
	 */
	public static void compress(String srcFile, String desFile, String password,
			String rarExePath) throws CompressException {
		 
		   StringBuffer winRar=new StringBuffer();
		   winRar.append(rarExePath);
		   winRar.append(" ");
		   winRar.append(" a ");
		   winRar.append(" -ep ");
		   winRar.append(" -o+ ");
		   
		   //�Ƿ�����ѹ��
		   if(null!=password){
			   winRar.append(" -hp"+password+" ");
		   }
		   
		   winRar.append(desFile);
		   winRar.append(" ");
		   winRar.append(srcFile);
		   
		   try{
			   Process process=Runtime.getRuntime().exec(winRar.toString());
			   if(process.waitFor()==0){
				   return;
			   }else{
				   throw new CompressException("ѹ��ʧ��");
			   }
		   }catch (Exception e) {
			   throw new CompressException(e.getMessage());
		}
		   
	}
	
	/**
	 * ��ѹ
	 * @param srcFile ��ѹԴ�ļ�
	 * @param desPath  ��ѹ��·��
	 * @param password  ��ѹ����  ����Ϊ�ձ�ʾ�������ѹ
	 * @param rarExePath  ��ѹ����װ·��
	 * @throws CompressException
	 */
	public static void deCompress(String srcFile, String desPath, String password,
			String rarExePath) throws CompressException {
		 StringBuffer winRar=new StringBuffer();
		   winRar.append(rarExePath);
		   winRar.append(" ");
		   winRar.append(" x ");
		   winRar.append(" -o+ ");
		   
		   if(null!=password){
			   winRar.append(" -hp"+password+" ");
		   }
		   
		   winRar.append(srcFile);
		   winRar.append(" ");
		   winRar.append(desPath);
		   
		   try{
			   Process process=Runtime.getRuntime().exec(winRar.toString());
			   if(process.waitFor()==0){
				   return;
			   }else{
				   throw new CompressException("��ѹʧ��");
			   }
		   }catch (Exception e) {
			   throw new CompressException(e.getMessage());
		}
		
	}

	

}
