package com.flink.compress.rar;

import com.flink.compress.CompressException;

/**
 * RARѹ�������� linux
 * @author ly
 * @date  2011-02-23 
 */
public class LinuxRarCompressHelper {

	/**
	 * ѹ��
	 * @param srcFile Դ�ļ�
	 * @param desFile  ѹ������ļ�
	 * @throws CompressException
	 */
	public static void compress(String srcFile, String desFile, String password) throws CompressException {
		 
		   StringBuffer linuxRar=new StringBuffer();
		   linuxRar.append(" rar ");
		   linuxRar.append(" a ");
		   linuxRar.append(" -ep ");
		   linuxRar.append(" -o+ ");
		   
		   //�Ƿ�����ѹ��
		   if(null!=password){
			   linuxRar.append(" -hp"+password+" ");
		   }
		   
		   linuxRar.append(desFile);
		   linuxRar.append(" ");
		   linuxRar.append(srcFile);
		   
		   try{
			   Process process=Runtime.getRuntime().exec(linuxRar.toString());
			   if(process.waitFor()==0){
				   return;
			   }else{
				   throw new CompressException("ѹ��ʧ��");
			   }
		   }catch (Exception e) {
			   throw new CompressException(e.getMessage());
		   }
		   
	}
	
	/**
	 * ��ѹ
	 * @param srcFile ��ѹ�ļ�
	 * @param desPath  ��ѹ��·��
	 * @param password  ��ѹ����
	 * @throws CompressException
	 */
	public static void deCompress(String srcFile, String desPath, String password) throws CompressException {
		   
		   StringBuffer linuxRar=new StringBuffer();
		   linuxRar.append(" rar ");
		   linuxRar.append(" x ");
		   linuxRar.append(" -o+ ");
		   
		   //�Ƿ������ѹ
		   if(null!=password){
			   linuxRar.append(" -hp"+password+" ");
		   }
		   
		   linuxRar.append(srcFile);
		   linuxRar.append(" ");
		   linuxRar.append(desPath);
		   
		   try{
			   Process process=Runtime.getRuntime().exec(linuxRar.toString());
			   if(process.waitFor()==0){
				   return;
			   }else{
				   throw new CompressException("��ѹʧ��");
			   }
		   }catch (Exception e) {
			   throw new CompressException(e.getMessage());
		   }
		
	}

}
