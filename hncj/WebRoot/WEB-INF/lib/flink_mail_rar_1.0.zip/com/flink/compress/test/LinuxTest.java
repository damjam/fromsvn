package com.flink.compress.test;

/**
 * RAR��� linux����
 * @author ly
 * @date  2011-02-23 
 */
public class LinuxTest {

	/**
	 * linuxѹ������
	 * @param srcFile
	 * @param desFile
	 * @param password
	 * @param rarExePath
	 */
	public void testRar(String srcFile, String desFile, String password,String rarExePath){
		 
		 StringBuffer linuxRar=new StringBuffer();
		   linuxRar.append(" rar ");
		   linuxRar.append(" a ");
		   linuxRar.append(" -ep ");
		   linuxRar.append(" -o+ ");
		   linuxRar.append(" -hp"+password+" ");
		   linuxRar.append(desFile);
		   linuxRar.append(" ");
		   linuxRar.append(srcFile);
		   
		   try{
			   Process process=Runtime.getRuntime().exec(linuxRar.toString());
			   if(process.waitFor()==0){
				   return;
			   }else{
				   throw new Exception("ѹ��ʧ��");
			   }
		   }catch (Exception e) {
			 e.printStackTrace();
		   }
	}
	
	/**
	 * ��ѹ������
	 * @param srcFile
	 * @param desPath
	 * @param password
	 * @param rarExePath
	 */
	public void testUnRar(String srcFile, String desPath, String password,
			String rarExePath){
		 
		 StringBuffer linuxRar=new StringBuffer();
		   linuxRar.append(" rar ");
		   linuxRar.append(" x ");
		   linuxRar.append(" -o+ ");
		   linuxRar.append(" -hp"+password+" ");
		   linuxRar.append(srcFile);
		   linuxRar.append(" ");
		   linuxRar.append(desPath);
		   
		   try{
			   Process process=Runtime.getRuntime().exec(linuxRar.toString());
			   if(process.waitFor()==0){
				   return;
			   }else{
				   throw new Exception("��ѹʧ��");
			   }
		   }catch (Exception e) {
			  e.printStackTrace();
		   }
	}
	
	public static void main(String[] args) throws Exception {
		
		LinuxTest linuxTest=new LinuxTest();

		if("0".equals(args[0])){
			System.out.println("compress");
			linuxTest.testRar(args[1], args[2], args[3], args[4]);
		}


		if("1".equals(args[0])){
			System.out.println("uncompress");
			linuxTest.testUnRar(args[1], args[2], args[3], args[4]);
		}
	}
}
